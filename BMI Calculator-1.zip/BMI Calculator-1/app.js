



function calculateBMI(){

    let heightFeet = parseFloat(document.getElementById("heightFeet").value) || 0;
    let heightInches = parseFloat(document.getElementById("heightInches").value) || 0;
    let weight = parseFloat(document.getElementById("weight").value) || 0;

     // Convert height to meters
     let heightMeters = ((heightFeet * 12) + heightInches) * 0.0254;

     // Calculate BMI
     let bmi = weight / (heightMeters ** 2);
    //  let resultText = `Your BMI: ${bmi.toFixed(2)} - `;
    
    let resultText = "Your BMI: " + bmi.toFixed(2) + " - ";


    // BMI Categories
    if (bmi < 18.5) {
        resultText=resultText+ "Underweight";
    } else if (bmi < 24.9) {
        resultText += "Normal weight";
    } else if (bmi < 29.9) {
        resultText += "Overweight";
    } else {
        resultText += "Obese";
    }



    let resultElement = document.getElementById("result");
    resultElement.innerText = resultText;
    // document.getElementById("result").innerText = resultText;
}
